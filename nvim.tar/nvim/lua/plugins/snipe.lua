return {
	"leath-dub/snipe.nvim",
	keys = {
		{
			"<leader>m",
			function()
				require("snipe").open_buffer_menu()
			end,
			desc = "Open Snipe buffer menu",
		},
	},
	opts = {
		ui = {
			-- Where to place the ui window
			-- Can be any of "topleft", "bottomleft", "topright", "bottomright", "center", "cursor" (sets under the current cursor pos)
			position = "center",
		},
		hints = {
			-- Charaters to use for hints
			-- make sure they don't collide with the navigation keymaps
			-- If you remove `j` and `k` from below, you can navigate in the plugin
			-- dictionary = "sadflewcmpghio",
			dictionary = "fjdksl",
		},
		navigate = {
			-- In case you changed your mind, provide a keybind that lets you
			-- cancel the snipe and close the window.
			-- cancel_snipe = "<esc>",
			cancel_snipe = "q",
		},
	},
}
