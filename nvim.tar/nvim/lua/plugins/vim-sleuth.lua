return {
  -- Detect tabstop and shiftwidth automatically
  'tpope/vim-sleuth',
}
